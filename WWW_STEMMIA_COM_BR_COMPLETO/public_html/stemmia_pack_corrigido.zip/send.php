<?php
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["email"])) {
    $email = trim(strtolower($_POST["email"]));
    $arquivo = "leads.txt";
    $dataHora = date("Y-m-d H:i:s");
    $ip = $_SERVER["REMOTE_ADDR"];
    $destinoEmail = "leads@stemmia.com.br";

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $linha = "$dataHora - $email - IP: $ip" . PHP_EOL;
        file_put_contents($arquivo, $linha, FILE_APPEND | LOCK_EX);

        $assunto = "📩 Novo Cadastro – STEMMIA";
        $mensagem = "Novo lead:\n\n📧 $email\n🕒 $dataHora\n🌐 IP: $ip";
        $headers = "From: STEMMIA <noreply@stemmia.com.br>\r\n" .
                   "Reply-To: noreply@stemmia.com.br\r\n" .
                   "Content-Type: text/plain; charset=UTF-8";

        mail($destinoEmail, $assunto, $mensagem, $headers);

        $assuntoUsuario = "🎉 Cadastro confirmado – STEMMIA";
        $mensagemUsuario = "Olá!\n\nVocê foi incluído na lista prioritária da STEMMIA. Em breve, enviaremos as novidades do lançamento do eBook.\n\nEquipe STEMMIA";
        mail($email, $assuntoUsuario, $mensagemUsuario, $headers);

        header("Location: obrigado.html");
        exit;
    } else {
        echo "E-mail inválido.";
    }
} else {
    echo "Requisição inválida.";
}
?>